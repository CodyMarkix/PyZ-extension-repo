import pyzapi.apicon as apicon

def change(newprompt):
    apicon.client.send(' '.join(["pyzchprompt", newprompt]))