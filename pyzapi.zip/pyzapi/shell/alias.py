import pyzapi.apicon as apicon

def setalias(aliasname, cmd):
    apicon.client.send(f"setalias {aliasname} {cmd}")