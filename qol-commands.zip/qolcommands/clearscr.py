def clear():
    import os

    if "nt" in os.name:
        clsc = "cls"
    else:
        clsc = "clear"

    os.system(clsc)