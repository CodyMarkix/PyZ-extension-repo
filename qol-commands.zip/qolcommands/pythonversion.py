def pyver():
    from platform import python_version
    print("Python version: "+ python_version())