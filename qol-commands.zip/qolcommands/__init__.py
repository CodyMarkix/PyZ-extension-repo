from qolcommands.clearscr import *
from qolcommands.listdir import *
from qolcommands.pythonversion import *