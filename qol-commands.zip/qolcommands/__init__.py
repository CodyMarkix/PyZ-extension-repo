from qolcommands.clear import *
from qolcommands.listdir import *
from qolcommands.pythonversion import *