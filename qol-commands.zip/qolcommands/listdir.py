def ls():
    import os
    print('\n'.join(os.listdir(os.curdir)))