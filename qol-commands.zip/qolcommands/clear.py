def clearscr():
    import os

    if os.name in "NT":
        clsc = "cls"
    else:
        clsc = "clear"

    os.system(clsc)