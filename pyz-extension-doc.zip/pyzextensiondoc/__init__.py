"""PyZ extensions - how they work:

When the program opens, it cycles through every folder in the plugins directory
and imports any plugins it can find.

PyZ extensions are written in Python and
some sort of API is not seen as a possible
feature right now, but that could change
later."""